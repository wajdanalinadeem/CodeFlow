// File: content.js
let rootHandle = null;
let activeFolderHandle = null;
let lastUpdate = null; 
const fileHandleMap = new Map();
const dbName = "AI_Project_DB";

async function getDB() {
  return new Promise((resolve) => {
    const request = indexedDB.open(dbName, 2);
    request.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("projects")) db.createObjectStore("projects");
      if (!db.objectStoreNames.contains("history")) db.createObjectStore("history", { autoIncrement: true });
    };
    request.onsuccess = () => resolve(request.result);
  });
}

async function saveProject(name, handle) {
  const db = await getDB();
  const tx = db.transaction("projects", "readwrite");
  await tx.objectStore("projects").put(handle, name);
}

async function deleteProject(name) {
  const db = await getDB();
  const tx = db.transaction("projects", "readwrite");
  await tx.objectStore("projects").delete(name);
  renderProjectGrid();
}

async function getSavedProjects() {
  const db = await getDB();
  return new Promise((resolve) => {
    const tx = db.transaction("projects", "readonly");
    const request = tx.objectStore("projects").getAllKeys();
    request.onsuccess = () => resolve(request.result);
  });
}

async function saveToHistory(fileName, content) {
  const db = await getDB();
  const tx = db.transaction("history", "readwrite");
  tx.objectStore("history").add({ fileName, content, timestamp: Date.now() });
}

function injectUI() {
  if (document.getElementById('ai-project-btn')) return;
  const btn = document.createElement('button');
  btn.innerText = '📁 Projects';
  btn.id = 'ai-project-btn';
  document.body.appendChild(btn);
  const sidebar = document.createElement('div');
  sidebar.id = 'ai-project-sidebar';
  sidebar.innerHTML = `
    <div id="custom-prompt-modal" style="display:none; position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); background:var(--header-bg); padding:15px; border:1px solid var(--accent-color); border-radius:8px; z-index:100000; flex-direction:column; gap:10px; width: 80%; box-shadow: 0 4px 15px rgba(0,0,0,0.5);">
      <label id="custom-prompt-label" style="font-size: 13px;"></label>
      <input type="text" id="custom-prompt-input" style="background:#111; color:white; border:1px solid var(--border-color); padding:8px; border-radius:4px; outline:none;">
      <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:5px;">
        <button id="custom-prompt-cancel" style="background:transparent; color:var(--text-dim); border:none; cursor:pointer;">Cancel</button>
        <button id="custom-prompt-submit" style="background:var(--accent-color); color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer;">OK</button>
      </div>
    </div>
    <div class="sidebar-header">
      <span id="sidebar-title">PROJECTS</span>
      <div class="sidebar-actions">
        <button class="action-btn" id="btn-back" title="Back to Projects" style="display:none">⬅️</button>
        <button class="action-btn" id="btn-undo" title="Undo Last Update" disabled style="opacity:0.5">↩️</button>
        <button class="action-btn" id="btn-new-file" title="New File" style="display:none">📄</button>
        <button class="action-btn" id="btn-new-folder" title="New Folder" style="display:none">📁</button>
        <button class="action-btn" id="btn-refresh" title="Refresh" style="display:none">🔄</button>
        <button class="action-btn" id="close-sidebar" title="Close">✕</button>
      </div>
    </div>
    <div id="search-container" style="display:none; padding: 10px; border-bottom: 1px solid var(--border-color);">
      <input type="text" id="tree-search" placeholder="Search files..." style="width:100%; background:#111; border:1px solid var(--border-color); color:white; padding:5px; border-radius:4px; font-size:12px;">
      <div id="drop-create-zone" style="margin-top: 10px; border: 1px dashed var(--border-color); border-radius: 4px; padding: 10px; text-align: center; font-size: 11px; color: var(--text-dim);">
        ➕ Drop code here to create file
      </div>
    </div>
    <div id="project-grid" class="project-grid" style="overflow-y:auto; flex-grow:1;"></div>
    <div id="file-tree" style="display:none; overflow-y:auto; flex-grow:1;"></div>
    <div id="banner-ad-container" class="banner-ad">
      <div style="width:100%; height:auto; text-align:center; font-size:0;">
        <div id="frame" style="width: 100%; margin: auto; position: relative;">
          <iframe 
            data-aa="2429790" 
            src="//acceptable.a-ads.com/2429790/?size=Adaptive" 
            style="border:0; padding:0; width:100%; height:80px; overflow:hidden; margin: auto;">
          </iframe>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(sidebar);
  setupEventListeners();
  setupDropZone();
}

function setupEventListeners() {
  const sidebar = document.getElementById('ai-project-sidebar');
  const btn = document.getElementById('ai-project-btn');
  btn.onclick = () => {
    sidebar.classList.toggle('open');
    if (sidebar.classList.contains('open') && !rootHandle) renderProjectGrid();
  };
  document.getElementById('close-sidebar').onclick = () => sidebar.classList.remove('open');
  document.getElementById('btn-back').onclick = () => renderProjectGrid();
  document.getElementById('btn-refresh').onclick = () => rootHandle && renderProject();
  
  document.getElementById('btn-new-file').onclick = async () => {
    const name = await askUser("File Name (e.g., script.js):");
    if (name && activeFolderHandle) {
      try { await activeFolderHandle.getFileHandle(name, { create: true }); renderProject(); } 
      catch(e) { alert("Failed: " + e.message); }
    }
  };
  
  document.getElementById('btn-new-folder').onclick = async () => {
    const name = await askUser("Folder Name:");
    if (name && activeFolderHandle) {
      try { await activeFolderHandle.getDirectoryHandle(name, { create: true }); renderProject(); } 
      catch(e) { alert("Failed: " + e.message); }
    }
  };

  document.getElementById('btn-undo').onclick = async () => {
    if (lastUpdate) {
      try {
        const writable = await lastUpdate.handle.createWritable();
        await writable.write(lastUpdate.content);
        await writable.close();
        document.getElementById('btn-undo').disabled = true;
        document.getElementById('btn-undo').style.opacity = "0.5";
        lastUpdate = null;
        renderProject();
      } catch (e) { alert('Undo failed: ' + e.message); }
    }
  };

  document.getElementById('tree-search').oninput = (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('.file-node').forEach(node => {
      node.style.display = node.innerText.toLowerCase().includes(term) ? 'flex' : 'none';
    });
  };
}

function setupDropZone() {
  const dropZone = document.getElementById('drop-create-zone');
  if (!dropZone) return;
  dropZone.ondragover = (e) => { e.preventDefault(); dropZone.style.borderColor = 'var(--accent-color)'; dropZone.style.color = '#fff'; };
  dropZone.ondragleave = () => { dropZone.style.borderColor = 'var(--border-color)'; dropZone.style.color = 'var(--text-dim)'; };
  dropZone.ondrop = async (e) => {
    e.preventDefault();
    dropZone.style.borderColor = 'var(--border-color)';
    const code = e.dataTransfer.getData('text/plain');
    if (code && activeFolderHandle) {
      const name = await askUser("New File Name:");
      if (name) {
        try {
          const fileHandle = await activeFolderHandle.getFileHandle(name, { create: true });
          const writable = await fileHandle.createWritable();
          await writable.write(code);
          await writable.close();
          renderProject();
        } catch (err) { alert("Create failed: " + err.message); }
      }
    }
  };
}

async function openProject(name) {
  const db = await getDB();
  const tx = db.transaction("projects", "readonly");
  const handle = await new Promise(r => {
    const req = tx.objectStore("projects").get(name);
    req.onsuccess = () => r(req.result);
  });
  if (handle) {
    try {
      if ((await handle.queryPermission({ mode: 'readwrite' })) !== 'granted') {
        await handle.requestPermission({ mode: 'readwrite' });
      }
      rootHandle = handle;
      activeFolderHandle = rootHandle;
      document.getElementById('sidebar-title').innerText = name.toUpperCase();
      document.getElementById('project-grid').style.display = 'none';
      document.getElementById('search-container').style.display = 'block';
      document.getElementById('file-tree').style.display = 'block';
      document.getElementById('btn-back').style.display = 'inline-block';
      ['btn-new-file', 'btn-new-folder', 'btn-refresh'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'inline-block';
      });
      renderProject();
    } catch (err) { console.error("Access denied", err); }
  }
}

async function renderProjectGrid() {
  const grid = document.getElementById('project-grid');
  document.getElementById('sidebar-title').innerText = "PROJECTS";
  grid.style.display = 'grid';
  document.getElementById('search-container').style.display = 'none';
  document.getElementById('file-tree').style.display = 'none';
  document.getElementById('btn-back').style.display = 'none';
  ['btn-new-file', 'btn-new-folder', 'btn-refresh'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
  grid.innerHTML = '';
  rootHandle = null;
  const projects = await getSavedProjects();
  const newCard = document.createElement('div');
  newCard.className = 'project-card add-card';
  newCard.innerHTML = `<span>+</span><small>New Project</small>`;
  newCard.onclick = async () => {
    const name = await askUser("Project Name:");
    if (name) {
      try {
        const handle = await window.showDirectoryPicker();
        await saveProject(name, handle);
        renderProjectGrid();
      } catch (err) { console.log("Cancelled"); }
    }
  };
  grid.appendChild(newCard);
  projects.forEach(name => {
    const card = document.createElement('div');
    card.className = 'project-card';
    card.innerHTML = `<div class="delete-proj">×</div><b>${name}</b>`;
    card.onclick = () => openProject(name);
    card.querySelector('.delete-proj').onclick = (e) => {
      e.stopPropagation();
      if(confirm(`Remove ${name}?`)) deleteProject(name);
    };
    grid.appendChild(card);
  });
}

async function handleSmartWrite(fileHandle, inputContent, element) {
  // Clean language identifiers often added to the first line by ChatGPT
  const commonLangs = ['javascript', 'js', 'python', 'py', 'csharp', 'c#', 'cpp', 'html', 'css', 'json', 'typescript', 'ts', 'java', 'rust', 'go', 'php', 'sql', 'ruby', 'xml', 'yaml'];
  const lines = inputContent.split('\n');
  if (lines.length > 0 && commonLangs.includes(lines[0].trim().toLowerCase())) {
    inputContent = lines.slice(1).join('\n');
  }

  const iconSpan = element ? element.querySelector('.icon') : null;
  const originalIcon = iconSpan ? iconSpan.innerText : '📄';
  if (iconSpan) iconSpan.innerHTML = '<div class="spinner"></div>';

  try {
    if (await fileHandle.queryPermission({ mode: 'readwrite' }) !== 'granted') {
      await fileHandle.requestPermission({ mode: 'readwrite' });
    }

    const file = await fileHandle.getFile();
    const currentFileText = await file.text();
    let finalOutput = currentFileText;

    const replaceRegex = /#replace\s+([\s\S]*?)\s+#with\s+([\s\S]*)/i;
    // Updated regex to optionally capture a line number after #add
    const addRegex = /#add\s*(\d+)?\s+([\s\S]*)/i;

    const replaceMatch = inputContent.match(replaceRegex);
    const addMatch = inputContent.match(addRegex);

    if (replaceMatch) {
      const oldSnippet = replaceMatch[1].trim();
      const newSnippet = replaceMatch[2].trim();
      
      const escapeRegExp = (str) => str ? str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') : '';
      const flexibleRegexStr = escapeRegExp(oldSnippet).split(/\s+/).join('\\s+');
      const searchRegex = new RegExp(flexibleRegexStr);
      
      if (searchRegex.test(currentFileText)) {
        // Using function callback to prevent '$' symbol issues in newSnippet
        finalOutput = currentFileText.replace(searchRegex, () => newSnippet);
      } else {
        throw new Error("Target code snippet not found in file. Ensure there are no typos beyond spacing.");
      }
    } else if (addMatch) {
      const lineNumber = addMatch[1] ? parseInt(addMatch[1], 10) : null;
      const newCode = addMatch[2].trim();
      
      if (lineNumber !== null) {
        const lines = currentFileText.split('\n');
        // Insert after the specified line (clamped between 0 and file length)
        const insertAt = Math.min(Math.max(lineNumber, 0), lines.length);
        lines.splice(insertAt, 0, newCode);
        finalOutput = lines.join('\n');
      } else {
        // Default behavior: Append to end
        finalOutput = currentFileText.endsWith('\n') ? 
          currentFileText + newCode : 
          currentFileText + '\n\n' + newCode;
      }
    } else {
      finalOutput = inputContent;
    }

    await saveToHistory(fileHandle.name, currentFileText);
    lastUpdate = { handle: fileHandle, content: currentFileText };
    
    const undoBtn = document.getElementById('btn-undo');
    if (undoBtn) {
      undoBtn.disabled = false;
      undoBtn.style.opacity = "1";
    }

    const writable = await fileHandle.createWritable();
    await writable.write(finalOutput);
    await writable.close();

    if (iconSpan) {
      iconSpan.innerText = '✅';
      setTimeout(() => { iconSpan.innerText = originalIcon; }, 2000);
    }
  } catch (err) {
    if (iconSpan) {
      iconSpan.innerText = '❌';
      setTimeout(() => { iconSpan.innerText = originalIcon; }, 3000);
    }
    console.error("SmartWrite Error:", err);
    alert(err.message);
  }
}

async function renderProject() {
  const tree = document.getElementById('file-tree');
  if (!tree) return;
  tree.innerHTML = '';
  fileHandleMap.clear();
  await buildTree(rootHandle, tree, 0);
}

async function buildTree(handle, container, depth) {
  const entries = [];
  for await (const entry of handle.values()) entries.push(entry);
  entries.sort((a, b) => (b.kind === 'directory') - (a.kind === 'directory') || a.name.localeCompare(b.name));
  for (const entry of entries) {
    const node = document.createElement('div');
    node.className = 'file-node';
    node.style.paddingLeft = `${15 + (depth * 12)}px`;
    if (entry.kind === 'directory') {
      node.innerHTML = `<span class="chevron">▶</span><span class="icon">📁</span>${entry.name}`;
      const childContainer = document.createElement('div');
      childContainer.style.display = 'none';
      node.onclick = (e) => {
        e.stopPropagation();
        const isCollapsed = childContainer.style.display === 'none';
        childContainer.style.display = isCollapsed ? 'block' : 'none';
        node.querySelector('.chevron').innerText = isCollapsed ? '▼' : '▶';
      };
      container.appendChild(node);
      container.appendChild(childContainer);
      await buildTree(entry, childContainer, depth + 1);
    } else {
      const fileId = Math.random().toString(36).substr(2, 9);
      fileHandleMap.set(fileId, { handle: entry, name: entry.name });
      node.innerHTML = `
        <span class="chevron"></span>
        <span class="icon">📄</span>
        <span style="flex-grow:1">${entry.name}</span>
        <span class="quick-paste" data-id="${fileId}">⚡</span>
      `;
      node.setAttribute('draggable', 'true');
      node.ondragstart = (e) => e.dataTransfer.setData('text/plain', `FILE_TRANSFER:${fileId}`);
      node.querySelector('.quick-paste').onclick = async (e) => {
        e.stopPropagation();
        const data = fileHandleMap.get(fileId);
        const input = document.querySelector('#prompt-textarea, .ql-editor, [contenteditable="true"]');
        if (data && input) {
          const f = await data.handle.getFile();
          const content = `\n// File: ${data.name}\n${await f.text()}\n`;
          input.focus();
          document.execCommand('insertText', false, content);
          input.dispatchEvent(new Event('input', { bubbles: true }));
          const btn = e.target;
          btn.innerText = '✅';
          setTimeout(() => { btn.innerText = '⚡'; }, 1000);
        }
      };
      node.ondragover = (e) => { e.preventDefault(); node.classList.add('drag-over'); };
      node.ondragleave = () => node.classList.remove('drag-over');
      node.ondrop = async (e) => {
        e.preventDefault();
        node.classList.remove('drag-over');
        const code = e.dataTransfer.getData('text/plain');
        if (code && !code.startsWith('FILE_TRANSFER:')) await handleSmartWrite(entry, code, node);
      };
      container.appendChild(node);
    }
  }
}

const observer = new MutationObserver(() => {
  document.querySelectorAll('pre').forEach(block => {
    if (block.dataset.hooked) return;
    block.dataset.hooked = "true";
    block.setAttribute('draggable', 'true');
    block.ondragstart = (e) => {
      const code = (block.querySelector('code') || block).innerText;
      e.dataTransfer.setData('text/plain', code);
    };
  });
  const input = document.querySelector('#prompt-textarea, .ql-editor, [contenteditable="true"]');
  if (input && !input.dataset.hooked) {
    input.dataset.hooked = "true";
    const targetContainer = input.closest('form') || input.parentElement;
    input.addEventListener('dragover', (e) => { e.preventDefault(); targetContainer.classList.add('drag-target'); });
    input.addEventListener('dragleave', () => targetContainer.classList.remove('drag-target'));
    input.addEventListener('drop', async (e) => {
      e.preventDefault();
      targetContainer.classList.remove('drag-target');
      const raw = e.dataTransfer.getData('text/plain');
      let finalContent = "";
      if (raw.startsWith('FILE_TRANSFER:')) {
        const data = fileHandleMap.get(raw.split(':')[1]);
        if (data) {
          const f = await data.handle.getFile();
          finalContent += `\n// File: ${data.name}\n${await f.text()}\n`;
        }
      } else {
        finalContent += raw;
      }
      input.focus();
      document.execCommand('insertText', false, finalContent);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    });
  }
});

function askUser(message) {
  return new Promise((resolve) => {
    const modal = document.getElementById('custom-prompt-modal');
    const input = document.getElementById('custom-prompt-input');
    const submitBtn = document.getElementById('custom-prompt-submit');
    const cancelBtn = document.getElementById('custom-prompt-cancel');
    
    if (!modal || !input) return resolve(null);

    document.getElementById('custom-prompt-label').innerText = message;
    input.value = '';
    modal.style.display = 'flex';
    input.focus();

    const cleanup = () => {
      modal.style.display = 'none';
      submitBtn.onclick = null;
      cancelBtn.onclick = null;
      input.onkeydown = null;
    };

    submitBtn.onclick = () => { resolve(input.value); cleanup(); };
    cancelBtn.onclick = () => { resolve(null); cleanup(); };
    input.onkeydown = (e) => {
      if (e.key === 'Enter') submitBtn.click();
      if (e.key === 'Escape') cancelBtn.click();
    };
  });
}

injectUI();
observer.observe(document.body, { childList: true, subtree: true });
